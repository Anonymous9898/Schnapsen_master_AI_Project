# Import the API objects
from api import State, util
from api import Deck
import random


class Bot:

    __max_depth = -1
    __randomize = True

    def __init__(self, randomize=True, depth=8):
        self.__randomize = randomize
        self.__max_depth = depth

    def get_move(self, state):

        # type: (State) -> tuple[int, int]
        """
        ///////////////////////////////////////////////////////////////////////
        Strategies:

    Phase 1:
    Opponent's turn:(non_trump) Done

        -Opponent plays jack (non-trump): Done
            The bot plays the highest card of the same suit except those two conditions:
                Bot has queen and king and 10 and A of the same suit → bot plays A of the same suit
                Bot has queen and king and 10 --> bot plays a 10 of the same suit
                Bot has queen and king --> bot plays the lowest card of other suits except trump suit.

        -Opponent plays queen (non-trump): Done
            Bot has 10 or A or King→ bot plays the highest one
            Bot does not have king but other same suit cards → bot plays highest same suit card
            Bot does not have same suit cards → bot plays lowest non-trump card

        -Opponent plays king (non-trump): Done
            Bot has higher same suit card →bot plays the card
            Bot has jack or queen → bot plays jack or queen
            Bot does not have same suit cards → bot plays lowest non trump card

        -Opponent plays ten (non-trump): Done
            Bot has the ace of the same suit → bot plays ace
            Bot has trump cards (not both queen and king)  → bot plays lowest trump card except for king and queen
            else : play lowest card

        -Opponent plays ace (non-trump): Done
            Bot has Jack, A, 10 of trump --> bot plays lowest trump card
            Else --> bot plays lowest card

        -Opponent plays jack, queen, king or ace of trump: Done
            Bot plays lowest non-trump card

        -Opponent plays ten of trump: Done
            Bot has ace of trump → plays it
            Bot does not have ace of trump → plays lowest non-trump card

        Bot Turn:
            Bot has jack of trump → bot exchanges card Done

            Bot has queen and king of any suit → bot plays them (marriage) Done

            Bot has queen of any suit → check previous trick for king of that suit → if yes, play the queen

            Bot has king of any suit → check previous trick for queen of that suit → if yes, play the king

            Bot plays lowest non-trump card Done

        :param State state: An object representing the gamestate. This includes a link to
            the states of all the cards, the trick and the points.
        :return: A tuple of integers or a tuple of an integer and None,
            indicating a move; the first indicates the card played in the trick, the second a
            potential spouse.
        """
        # All legal moves
        moves = state.moves()
        chosen_move = moves[0]

        # if first phase
        moves_trump_suit = []
        phase = state.get_phase()
        if phase == 1:

            # if the opponent has played a card:
            if state.get_opponents_played_card() is not None:
                opponent_card = state.get_opponents_played_card()
                trump = state.get_trump_suit()

                if trump == 'C':

                    # if the opponent played a non trump jack
                    if opponent_card == 9 or opponent_card == 14 or opponent_card == 19:
                        moves_same_suit = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        if len(moves_same_suit) > 0:
                            moves_same_suit_rank = []
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                            if ('10' in moves_same_suit_rank) or ('A' in moves_same_suit_rank):
                                # print("10 or A is played")
                                chosen_move = min(moves_same_suit)
                            elif ('K' in moves_same_suit_rank) or ('Q' in moves_same_suit_rank):
                                # print("moves:", moves)
                                # print("moves same suit", moves_same_suit)
                                for move in moves_same_suit:
                                    moves.remove(move)
                                for x in reversed(moves):
                                    if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                        moves.remove(x)
                                if len(moves) > 0:
                                    for index in moves:
                                        if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                            chosen_move = index
                                elif len(moves) == 0:
                                    chosen_move = max(moves_trump_suit)
                                # print("moves (non-trump and not the same suit):", moves)
                                # print("king or queen is kept")
                        elif len(moves_same_suit) == 0:
                            # print("moves:", moves)
                            # moves_copy = moves
                            for x in reversed(moves):
                                if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                    moves.remove(x)
                            if len(moves) > 0:
                                for index in moves:
                                    if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                        chosen_move = index
                            elif len(moves) == 0:
                                chosen_move = max(moves_trump_suit)
                            # print("moves (non-trump):", moves)
                            # print("lowest non-trump card is played")

                    # if the opponent played a non-trump queen
                    elif opponent_card == 8 or opponent_card == 13 or opponent_card == 18:
                        moves_same_suit = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        # if you have same suit moves
                        if len(moves_same_suit) > 0:
                            moves_same_suit_rank = []
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                            chosen_move = min(moves_same_suit)
                            # print("Highest same suit card has been played")
                        # if you have no same suit moves, play the lowest non-trump card
                        elif len(moves_same_suit) == 0:
                            # print("moves:", moves)
                            for x in reversed(moves):
                                if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                    moves.remove(x)
                            if len(moves) > 0:
                                for index in moves:
                                    if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                        chosen_move = index
                            elif len(moves) == 0:
                                chosen_move = max(moves_trump_suit)
                            # print("moves (non-trump):", moves)
                            # print("lowest non-trump card is played")

                    # if the opponent played a non trump King
                    elif opponent_card == 7 or opponent_card == 12 or opponent_card == 17:
                        moves_same_suit = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        # if you have same suit moves
                        if len(moves_same_suit) > 0:
                            moves_same_suit_rank = []
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                            if ('10' in moves_same_suit_rank) or ('A' in moves_same_suit_rank):
                                # print("10 or A is played")
                                chosen_move = min(moves_same_suit)
                            elif ('J' in moves_same_suit_rank) or ('Q' in moves_same_suit_rank):
                                chosen_move = max(moves_same_suit)
                                # print("J or Q is played")
                        # if you have no same suit moves, play the lowest non-trump card
                        elif len(moves_same_suit) == 0:
                            # print("moves:", moves)
                            for x in reversed(moves):
                                if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                    moves.remove(x)
                            if len(moves) > 0:
                                for index in moves:
                                    if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                        chosen_move = index
                            elif len(moves) == 0:
                                chosen_move = max(moves_trump_suit)
                            # print("moves (non-trump):", moves)
                            # print("lowest non-trump card is played")

                    # if the opponent played a non trump 10
                    elif opponent_card == 6 or opponent_card == 11 or opponent_card == 16:
                        moves_same_suit = []
                        moves_trump_suit_rank = []
                        moves_same_suit_rank = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        # if you have same suit moves
                        if len(moves_same_suit) > 0:
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                        if len(moves_trump_suit) > 0:
                            for i in moves_trump_suit:
                                moves_trump_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves trump suit ranks:", moves_same_suit_rank)
                        if 'A' in moves_same_suit_rank:
                            # print("A is played")
                            chosen_move = min(moves_same_suit)
                        elif ('A' in moves_trump_suit_rank) or ('10' in moves_trump_suit_rank):
                            chosen_move = min(moves_trump_suit)
                            # print("A or 10 of trump suit is played")
                        elif 'J' in moves_trump_suit_rank:
                            chosen_move = max(moves_trump_suit)
                            # print('Jack is played')
                        else:
                            for index in moves:
                                if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                    chosen_move = index
                            # print('lowest card has been played')

                    # if the opponent played a non trump Ace
                    elif opponent_card == 5 or opponent_card == 10 or opponent_card == 15:
                        moves_trump_suit_rank = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        if len(moves_trump_suit) > 0:
                            for i in moves_trump_suit:
                                moves_trump_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves trump suit ranks:", moves_trump_suit_rank)
                        if ('A' in moves_trump_suit_rank) or ('10' in moves_trump_suit_rank):
                            chosen_move = min(moves_trump_suit)
                            # print("A or 10 of trump suit is played")
                        elif 'J' in moves_trump_suit_rank:
                            chosen_move = max(moves_trump_suit)
                            # print('Jack is played')
                        else:
                            for index in moves:
                                if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                    chosen_move = index
                            # print('lowest card has been played')

                    # if the opponent played a Jack, Queen, King or Ace of trump:
                    if opponent_card == 4 or opponent_card == 3 or opponent_card == 2 or opponent_card == 0:
                        # remove all trump card from possible moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves.remove(x)
                        for index in moves:
                            if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                chosen_move = index
                        # print('lowest card has been played')

                    # if the opponent played 10 of trump:
                    if opponent_card == 1:
                        moves_trump_suit_rank = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        if len(moves_trump_suit) > 0:
                            for i in moves_trump_suit:
                                moves_trump_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves trump suit ranks:", moves_trump_suit_rank)
                        if 'A' in moves_trump_suit_rank:
                            chosen_move = min(moves_trump_suit)
                            # print("A of trump has been played")

                        else:
                            for index in moves:
                                if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                    chosen_move = index
                            # print('lowest card has been played')

                elif trump == 'D':

                    # if the opponent played a non trump jack
                    if opponent_card == 4 or opponent_card == 14 or opponent_card == 19:
                        moves_same_suit = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        if len(moves_same_suit) > 0:
                            moves_same_suit_rank = []
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                            if ('10' in moves_same_suit_rank) or ('A' in moves_same_suit_rank):
                                # print("10 or A is played")
                                chosen_move = min(moves_same_suit)
                            elif ('K' in moves_same_suit_rank) or ('Q' in moves_same_suit_rank):
                                # print("moves:", moves)
                                # print("moves same suit", moves_same_suit)
                                for move in moves_same_suit:
                                    moves.remove(move)
                                # moves_copy = moves
                                for x in reversed(moves):
                                    if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                        moves.remove(x)
                                if len(moves) > 0:
                                    for index in moves:
                                        if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                            chosen_move = index
                                elif len(moves) == 0:
                                    chosen_move = max(moves_trump_suit)
                                # print("moves (non-trump and not the same suit):", moves)
                                # print("king or queen is kept")
                        elif len(moves_same_suit) == 0:
                            # print("moves:", moves)
                            # moves_copy = moves
                            for x in reversed(moves):
                                if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                    moves.remove(x)
                            if len(moves) > 0:
                                for index in moves:
                                    if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                        chosen_move = index
                            elif len(moves) == 0:
                                chosen_move = max(moves_trump_suit)
                            # print("moves (non-trump):", moves)
                            # print("lowest non-trump card is played")

                    # if the opponent played a non trump queen
                    elif opponent_card == 3 or opponent_card == 13 or opponent_card == 18:
                        moves_same_suit = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        # if you have same suit moves
                        if len(moves_same_suit) > 0:
                            moves_same_suit_rank = []
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                            chosen_move = min(moves_same_suit)
                            # print("Highest same suit card has been played")
                        # if you have no same suit moves, play the lowest non-trump card
                        elif len(moves_same_suit) == 0:
                            # print("moves:", moves)
                            for x in reversed(moves):
                                if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                    moves.remove(x)
                            if len(moves) > 0:
                                for index in moves:
                                    if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                        chosen_move = index
                            elif len(moves) == 0:
                                chosen_move = max(moves_trump_suit)
                            # print("moves (non-trump):", moves)
                            # print("lowest non-trump card is played")

                    # if the opponent played a non trump King
                    elif opponent_card == 2 or opponent_card == 12 or opponent_card == 17:
                        moves_same_suit = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        # if you have same suit moves
                        if len(moves_same_suit) > 0:
                            moves_same_suit_rank = []
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                            if ('10' in moves_same_suit_rank) or ('A' in moves_same_suit_rank):
                                # print("10 or A is played")
                                chosen_move = min(moves_same_suit)
                            elif ('J' in moves_same_suit_rank) or ('Q' in moves_same_suit_rank):
                                chosen_move = max(moves_same_suit)
                                # print("J or Q is played")
                        # if you have no same suit moves, play the lowest non-trump card
                        elif len(moves_same_suit) == 0:
                            # print("moves:", moves)
                            for x in reversed(moves):
                                if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                    moves.remove(x)
                            if len(moves) > 0:
                                for index in moves:
                                    if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                        chosen_move = index
                            elif len(moves) == 0:
                                chosen_move = max(moves_trump_suit)
                            # print("moves (non-trump):", moves)
                            # print("lowest non-trump card is played")

                    # if the opponent played a non trump 10
                    elif opponent_card == 1 or opponent_card == 11 or opponent_card == 16:
                        moves_same_suit = []
                        moves_trump_suit_rank = []
                        moves_same_suit_rank = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        # if you have same suit moves
                        if len(moves_same_suit) > 0:
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                        if len(moves_trump_suit) > 0:
                            for i in moves_trump_suit:
                                moves_trump_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves trump suit ranks:", moves_same_suit_rank)
                        if 'A' in moves_same_suit_rank:
                            # print("A is played")
                            chosen_move = min(moves_same_suit)
                        elif ('A' in moves_trump_suit_rank) or ('10' in moves_trump_suit_rank):
                            chosen_move = min(moves_trump_suit)
                            # print("A or 10 of trump suit is played")
                        elif 'J' in moves_trump_suit_rank:
                            chosen_move = max(moves_trump_suit)
                            # print('Jack is played')
                        else:
                            for index in moves:
                                if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                    chosen_move = index
                            # print('lowest card has been played')

                    # if the opponent played a non trump Ace
                    elif opponent_card == 0 or opponent_card == 10 or opponent_card == 15:
                        moves_trump_suit_rank = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        if len(moves_trump_suit) > 0:
                            for i in moves_trump_suit:
                                moves_trump_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves trump suit ranks:", moves_trump_suit_rank)
                        if ('A' in moves_trump_suit_rank) or ('10' in moves_trump_suit_rank):
                            chosen_move = min(moves_trump_suit)
                            # print("A or 10 of trump suit is played")
                        elif 'J' in moves_trump_suit_rank:
                            chosen_move = max(moves_trump_suit)
                            # print('Jack is played')
                        else:
                            for index in moves:
                                if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                    chosen_move = index
                            # print('lowest card has been played')

                    # if the opponent played a Jack, Queen, King or Ace of trump:
                    if opponent_card == 5 or opponent_card == 7 or opponent_card == 8 or opponent_card == 9:
                        # remove all trump card from possible moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves.remove(x)
                        for index in moves:
                            if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                chosen_move = index
                        # print('lowest card has been played')

                    # if the opponent played 10 of trump:
                    if opponent_card == 6:
                        moves_trump_suit_rank = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        if len(moves_trump_suit) > 0:
                            for i in moves_trump_suit:
                                moves_trump_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves trump suit ranks:", moves_trump_suit_rank)
                        if 'A' in moves_trump_suit_rank:
                            chosen_move = min(moves_trump_suit)
                            # print("A of trump has been played")
                        else:
                            for index in moves:
                                if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                    chosen_move = index
                            # print('lowest card has been played')

                elif trump == 'H':

                    # if the opponent played a non trump jack
                    if opponent_card == 4 or opponent_card == 9 or opponent_card == 19:
                        moves_same_suit = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        if len(moves_same_suit) > 0:
                            moves_same_suit_rank = []
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                            if ('10' in moves_same_suit_rank) or ('A' in moves_same_suit_rank):
                                # print("10 or A is played")
                                chosen_move = min(moves_same_suit)
                            elif ('K' in moves_same_suit_rank) or ('Q' in moves_same_suit_rank):
                                # print("moves:", moves)
                                # print("moves same suit", moves_same_suit)
                                for move in moves_same_suit:
                                    moves.remove(move)
                                # moves_copy = moves
                                for x in reversed(moves):
                                    if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                        moves.remove(x)
                                if len(moves) > 0:
                                    for index in moves:
                                        if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                            chosen_move = index
                                elif len(moves) == 0:
                                    chosen_move = max(moves_trump_suit)
                                # print("moves (non-trump and not the same suit):", moves)
                                # print("king or queen is kept")
                        elif len(moves_same_suit) == 0:
                            # print("moves:", moves)
                            # moves_copy = moves
                            for x in reversed(moves):
                                if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                    moves.remove(x)
                            if len(moves) > 0:
                                for index in moves:
                                    if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                        chosen_move = index
                            elif len(moves) == 0:
                                chosen_move = max(moves_trump_suit)
                            # print("moves (non-trump):", moves)
                            # print("lowest non-trump card is played")

                    # if the opponent played  non-trump queen
                    elif opponent_card == 3 or opponent_card == 8 or opponent_card == 18:
                        moves_same_suit = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        # if you have same suit moves
                        if len(moves_same_suit) > 0:
                            moves_same_suit_rank = []
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                            chosen_move = min(moves_same_suit)
                            # print("Highest same suit card has been played")
                        # if you have no same suit moves, play the lowest non-trump card
                        elif len(moves_same_suit) == 0:
                            # print("moves:", moves)
                            for x in reversed(moves):
                                if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                    moves.remove(x)
                            if len(moves) > 0:
                                for index in moves:
                                    if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                        chosen_move = index
                            elif len(moves) == 0:
                                chosen_move = max(moves_trump_suit)
                            # print("moves (non-trump):", moves)
                            # print("lowest non-trump card is played")

                    # if the opponent played a non trump King
                    elif opponent_card == 2 or opponent_card == 7 or opponent_card == 17:
                        moves_same_suit = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        # if you have same suit moves
                        if len(moves_same_suit) > 0:
                            moves_same_suit_rank = []
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                            if ('10' in moves_same_suit_rank) or ('A' in moves_same_suit_rank):
                                # print("10 or A is played")
                                chosen_move = min(moves_same_suit)
                            elif ('J' in moves_same_suit_rank) or ('Q' in moves_same_suit_rank):
                                chosen_move = max(moves_same_suit)
                                # print("J or Q is played")
                        # if you have no same suit moves, play the lowest non-trump card
                        elif len(moves_same_suit) == 0:
                            # print("moves:", moves)
                            for x in reversed(moves):
                                if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                    moves.remove(x)
                            if len(moves) > 0:
                                for index in moves:
                                    if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                        chosen_move = index
                            elif len(moves) == 0:
                                chosen_move = max(moves_trump_suit)
                            # print("moves (non-trump):", moves)
                            # print("lowest non-trump card is played")

                    # if the opponent played a non trump 10
                    elif opponent_card == 1 or opponent_card == 6 or opponent_card == 16:
                        moves_same_suit = []
                        moves_trump_suit_rank = []
                        moves_same_suit_rank = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        # if you have same suit moves
                        if len(moves_same_suit) > 0:
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                        if len(moves_trump_suit) > 0:
                            for i in moves_trump_suit:
                                moves_trump_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves trump suit ranks:", moves_same_suit_rank)
                        if 'A' in moves_same_suit_rank:
                            # print("A is played")
                            chosen_move = min(moves_same_suit)
                        elif ('A' in moves_trump_suit_rank) or ('10' in moves_trump_suit_rank):
                            chosen_move = min(moves_trump_suit)
                            # print("A or 10 of trump suit is played")
                        elif 'J' in moves_trump_suit_rank:
                            chosen_move = max(moves_trump_suit)
                            # print('Jack is played')
                        else:
                            for index in moves:
                                if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                    chosen_move = index
                            # print('lowest card has been played')

                    # if the opponent played a non trump Ace
                    elif opponent_card == 0 or opponent_card == 5 or opponent_card == 15:
                        moves_trump_suit_rank = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        if len(moves_trump_suit) > 0:
                            for i in moves_trump_suit:
                                moves_trump_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves trump suit ranks:", moves_trump_suit_rank)
                        if ('A' in moves_trump_suit_rank) or ('10' in moves_trump_suit_rank):
                            chosen_move = min(moves_trump_suit)
                            # print("A or 10 of trump suit is played")
                        elif 'J' in moves_trump_suit_rank:
                            chosen_move = max(moves_trump_suit)
                            # print('Jack is played')
                        else:
                            for index in moves:
                                if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                    chosen_move = index
                            # print('lowest card has been played')

                    # if the opponent played a Jack, Queen, King or Ace of trump:
                    if opponent_card == 10 or opponent_card == 12 or opponent_card == 13 or opponent_card == 14:
                        # remove all trump card from possible moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves.remove(x)
                        for index in moves:
                            if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                chosen_move = index
                        # print('lowest card has been played')
                    # if the opponent played 10 of trump:
                    if opponent_card == 11:
                        moves_trump_suit_rank = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        if len(moves_trump_suit) > 0:
                            for i in moves_trump_suit:
                                moves_trump_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves trump suit ranks:", moves_trump_suit_rank)
                        if 'A' in moves_trump_suit_rank:
                            chosen_move = min(moves_trump_suit)
                            # print("A of trump has been played")
                        else:
                            for index in moves:
                                if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                    chosen_move = index
                            # print('lowest card has been played')

                elif trump == 'S':

                    # if the opponent played a non trump jack
                    if opponent_card == 4 or opponent_card == 9 or opponent_card == 14:
                        moves_same_suit = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        if len(moves_same_suit) > 0:
                            moves_same_suit_rank = []
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                            if ('10' in moves_same_suit_rank) or ('A' in moves_same_suit_rank):
                                # print("10 or A is played")
                                chosen_move = min(moves_same_suit)
                            elif ('K' in moves_same_suit_rank) or ('Q' in moves_same_suit_rank):
                                # print("moves:", moves)
                                # print("moves same suit", moves_same_suit)
                                for move in moves_same_suit:
                                    moves.remove(move)
                                # moves_copy = moves
                                for x in reversed(moves):
                                    if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                        moves.remove(x)
                                if len(moves) > 0:
                                    for index in moves:
                                        if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                            chosen_move = index
                                elif len(moves) == 0:
                                    chosen_move = max(moves_trump_suit)
                                # print("moves (non-trump and not the same suit):", moves)
                                # print("king or queen is kept")
                        elif len(moves_same_suit) == 0:
                            # print("moves:", moves)
                            # moves_copy = moves
                            for x in reversed(moves):
                                if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                    moves.remove(x)
                            if len(moves) > 0:
                                for index in moves:
                                    if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                        chosen_move = index
                            elif len(moves) == 0:
                                chosen_move = max(moves_trump_suit)
                            # print("moves (non-trump):", moves)
                            # print("lowest non-trump card is played")

                    # if the opponent played  non-trump queen
                    elif opponent_card == 3 or opponent_card == 8 or opponent_card == 13:
                        moves_same_suit = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        # if you have same suit moves
                        if len(moves_same_suit) > 0:
                            moves_same_suit_rank = []
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                            chosen_move = min(moves_same_suit)
                            # print("Highest same suit card has been played")
                        # if you have no same suit moves, play the lowest non-trump card
                        elif len(moves_same_suit) == 0:
                            # print("moves:", moves)
                            for x in reversed(moves):
                                if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                    moves.remove(x)
                            if len(moves) > 0:
                                for index in moves:
                                    if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                        chosen_move = index
                            elif len(moves) == 0:
                                chosen_move = max(moves_trump_suit)
                            # print("moves (non-trump):", moves)
                            # print("lowest non-trump card is played")

                    # if the opponent played a non trump King
                    elif opponent_card == 2 or opponent_card == 7 or opponent_card == 12:
                        moves_same_suit = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        # if you have same suit moves
                        if len(moves_same_suit) > 0:
                            moves_same_suit_rank = []
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                            if ('10' in moves_same_suit_rank) or ('A' in moves_same_suit_rank):
                                # print("10 or A is played")
                                chosen_move = min(moves_same_suit)
                            elif ('J' in moves_same_suit_rank) or ('Q' in moves_same_suit_rank):
                                chosen_move = max(moves_same_suit)
                                # print("J or Q is played")
                        # if you have no same suit moves, play the lowest non-trump card
                        elif len(moves_same_suit) == 0:
                            # print("moves:", moves)
                            for x in reversed(moves):
                                if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                    moves.remove(x)
                            if len(moves) > 0:
                                for index in moves:
                                    if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                        chosen_move = index
                            elif len(moves) == 0:
                                chosen_move = max(moves_trump_suit)
                            # print("moves (non-trump):", moves)
                            # print("lowest non-trump card is played")

                    # if the opponent played a non trump 10
                    elif opponent_card == 1 or opponent_card == 6 or opponent_card == 11:
                        moves_same_suit = []
                        moves_trump_suit_rank = []
                        moves_same_suit_rank = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        # Get all moves of the same suit as the opponent's played card
                        for move in moves:
                            if move[0] is not None and Deck.get_suit(move[0]) == Deck.get_suit(
                                    state.get_opponents_played_card()):
                                moves_same_suit.append(move)
                        # print("moves same suit:", moves_same_suit)
                        # if you have same suit moves
                        if len(moves_same_suit) > 0:
                            for i in moves_same_suit:
                                moves_same_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves same suit ranks:", moves_same_suit_rank)
                        if len(moves_trump_suit) > 0:
                            for i in moves_trump_suit:
                                moves_trump_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves trump suit ranks:", moves_same_suit_rank)
                        if 'A' in moves_same_suit_rank:
                            # print("A is played")
                            chosen_move = min(moves_same_suit)
                        elif ('A' in moves_trump_suit_rank) or ('10' in moves_trump_suit_rank):
                            chosen_move = min(moves_trump_suit)
                            # print("A or 10 of trump suit is played")
                        elif 'J' in moves_trump_suit_rank:
                            chosen_move = max(moves_trump_suit)
                            # print('Jack is played')
                        else:
                            for index in moves:
                                if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                    chosen_move = index
                            # print('lowest card has been played')

                    # if the opponent played a non trump Ace
                    elif opponent_card == 0 or opponent_card == 5 or opponent_card == 10:
                        moves_trump_suit_rank = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        if len(moves_trump_suit) > 0:
                            for i in moves_trump_suit:
                                moves_trump_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves trump suit ranks:", moves_trump_suit_rank)
                        if ('A' in moves_trump_suit_rank) or ('10' in moves_trump_suit_rank):
                            chosen_move = min(moves_trump_suit)
                            # print("A or 10 of trump suit is played")
                        elif 'J' in moves_trump_suit_rank:
                            chosen_move = max(moves_trump_suit)
                            # print('Jack is played')
                        else:
                            for index in moves:
                                if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                    chosen_move = index
                            # print('lowest card has been played')
                    # if the opponent played a Jack, Queen, King or Ace of trump:
                    if opponent_card == 15 or opponent_card == 17 or opponent_card == 18 or opponent_card == 19:
                        # remove all trump card from possible moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves.remove(x)
                        for index in moves:
                            if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                chosen_move = index
                        # print('lowest card has been played')
                    # if the opponent played 10 of trump:
                    if opponent_card == 16:
                        moves_trump_suit_rank = []
                        # get all trump moves
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves_trump_suit.append(x)
                        if len(moves_trump_suit) > 0:
                            for i in moves_trump_suit:
                                moves_trump_suit_rank.append(Deck.get_rank(i[0]))
                            # print("moves trump suit ranks:", moves_trump_suit_rank)
                        if 'A' in moves_trump_suit_rank:
                            chosen_move = min(moves_trump_suit)
                            # print("A of trump has been played")
                        else:
                            for index in moves:
                                if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                                    chosen_move = index
                            # print('lowest card has been played')

            else:  # if it is the bot turn

                if state.whose_turn() == state.leader():
                    # check for trump exchange
                    for move in moves:
                        if move[0] is None:
                            if move[1] is not None:
                                # print('Jack exchanged')
                                return move
                    # if you have a marriage play it
                    for index, move in enumerate(moves):
                        if move[0] is not None:
                            if move[1] is not None:
                                # print('marriage')
                                return move
                    # check for previous trick if king is there
                    previous_trick = state.get_prev_trick()
                    for i in moves:
                        if Deck.get_rank(i[0]) == 'Q':
                            if (i[0]-1) in previous_trick:
                                chosen_move = i
                                # print("non useful queen has been played")
                                return chosen_move
                        elif Deck.get_rank(i[0]) == 'K':
                            if (i[0]+1) in previous_trick:
                                chosen_move = i
                                # print("non useful king has been played")
                                return chosen_move

                    # get all trump moves
                    for x in reversed(moves):
                        if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                            moves_trump_suit.append(x)
                    # removes trump cards moves
                    if len(moves_trump_suit) > 0:
                        for x in reversed(moves):
                            if x[0] is not None and Deck.get_suit(x[0]) == state.get_trump_suit():
                                moves.remove(x)
                    # play lowest one
                    for index in moves:
                        if index[0] is not None and index[0] % 5 >= chosen_move[0] % 5:
                            chosen_move = index
                    # print('lowest card has been played')
        elif phase == 2:
            val, move = self.value(state)
            return move

        # print("hand", moves)
        # print(state.State__deck.__p1_perspective)
        return chosen_move

    def value(self, state, alpha=float('-inf'), beta=float('inf'), depth=0):
        """
        Return the value of this state and the associated move
        :param State state:
        :param float alpha: The highest score that the maximizing player can guarantee given current knowledge
        :param float beta: The lowest score that the minimizing player can guarantee given current knowledge
        :param int depth: How deep we are in the tree
        :return val, move: the value of the state, and the best move.
        """

        if state.finished():
            winner, points = state.winner()
            return (points, None) if winner == 1 else (-points, None)

        if depth == self.__max_depth:
            return heuristic(state)

        best_value = float('-inf') if maximizing(state) else float('inf')
        best_move = None

        moves = state.moves()

        if self.__randomize:
            random.shuffle(moves)

        for move in moves:

            next_state = state.next(move)
            value, _ = self.value(next_state, alpha, beta, depth=+1)

            if maximizing(state):
                if value > best_value:
                    best_value = value
                    best_move = move
                    alpha = best_value
            else:
                if value < best_value:
                    best_value = value
                    best_move = move
                    beta = best_value

            # Prune the search tree
            # We know this state will never be chosen, so we stop evaluating its children
            if alpha >= beta:
                break

        return best_value, best_move


def maximizing(state):
    # type: (State) -> bool
    """
    Whether we're the maximizing player (1) or the minimizing player (2).

    :param state:
    :return:
    """
    return state.whose_turn() == 1


def heuristic(state):
    # type: (State) -> float
    """
    Estimate the value of this state: -1.0 is a certain win for player 2, 1.0 is a certain win for player 1

    :param state:
    :return: A heuristic evaluation for the given state (between -1.0 and 1.0)
    """
    return util.ratio_points(state, 1) * 2.0 - 1.0, None
